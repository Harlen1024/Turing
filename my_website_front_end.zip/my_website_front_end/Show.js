$(function(){
	var h=window.innerHeight|| document.documentElement.clientHeight|| document.body.clientHeight;
	
	h-=80;
	
	$("#left_content").css("height",h+"px");
	
	$("#right_content").css("height",h+"px");
		
	$("#left_content").children().click(function(){
		var $this=this;
		$("#left_content").children().each(function(){
			if($(this).attr("class")=="right_content_g"){
				
			}
			if(this==$this){
				$("#"+$(this).attr("class")).css("display","flex");
				$(this).css("background-color","skyblue");
				$(this).css("color","black");
			}
			else{
				$("#"+$(this).attr("class")).css("display","none");
				$(this).css("background-color","white");
				$(this).css("color","darkgray");
			}
		})
	})
	$("#left_content").children(".right_content_a").click();
	
	var storage=window.localStorage;
	var type=storage.getItem("user_type");
	
	
	//选择文件，准备上传
	layui.use('upload', function(){
		var s=window.localStorage;
		var name=s.getItem("user_name");
		
	  var upload = layui.upload;
	  //执行实例
	  var uploadInst = upload.render({
		field:"file",
		elem:'#test1',//绑定元素
		auto:false,
		accept:"file",
		bindAction:"#af",
		url: 'http://47.95.3.253:8080/website/upload/setFileUpload' ,//上传接口
		choose:function(obj){
				$("#af").click();
		},
		data:{
			upload:name,
		},
		done: function(res){
			console.log("done");
		  //上传完毕回调
		}
		,error: function(){
		  //请求异常回调
		}
	  });
	});
	
	
	//加载个人信息
	var storage=window.localStorage;//创建访问localStorage的对象
	var user=storage.getItem("user_name");
	var type=storage.getItem("user_type");
	if(type=="user")
		axios({
			  method: 'get',
			  url:'http://47.95.3.253:8080/website/api/query/user/username/'+user,
			  responseType:'json',
		
		}).then(function(response) {
			$("#name").html(response.data.data.username);
			$("#user_name").html(response.data.data.username);
			if(response.data.data.sex==0){
				$("#sex").html("男");
			}
			else{
				$("#sex").html("女");
			}
			$("#id_num").html(response.data.data.info);
			$("#born").html(response.data.data.birth);
			

			var content;
			if(response.data.data.limit==1)
				content="可以上传下载";
			else if(response.data.data.limit==2)
				content="可以上传";
			else if(response.data.data.limit==3)
				content="可以下载";
			else if(response.data.data.limit==4)
				content="不可以上传下载";
			$("#nation").html(content);
			var storage=window.localStorage;//创建访问localStorage的对象
			storage.setItem("limit",response.data.data.limit);

			//加载上半部分信息
			
		}).catch(function (error) {
			alert("个人信息链接错误");
		});
		else if(type=="admin"){
			axios({
				  method: 'get',
				  url:'http://47.95.3.253:8080/website/api/query/admin/username/'+user,
				  responseType:'json',
			
			}).then(function(response) {
				$("#name").html(response.data.data.username+"<br/>"+"网站管理员");
				$("#user_name").html(response.data.data.username+"<br/>"+"网站管理员");
				
				//加载上半部分信息
				
			}).catch(function (error) {
				alert("个人信息链接错误");
			});
		}
	

	//退出按钮
	$("#login_out").click(function(){
		var storage=window.localStorage;
		storage.clear();
		window.open("index.html");
		window.close();
	});
	
	//个人信息点击跳转
	$("#user_name").click(function(){
		$(".right_content_f").click();
	})
	
	//企业总情况
	axios({
		method: 'get',
		url:'http://47.95.3.253:8080/website/api/query/file/loads',
		responseType:'json',
	}).then(function(response){
		
		$("#total_number>div:last").html(response.data.data.all);
		$("#Turnover>div:last").html(response.data.data.uploads);
		$("#gross_wage>div:last").html(response.data.data.downloads);
		
	}).catch(function (error){
	});
	
	//加载部门信息

		if(type=="user"){
			getall(1,"right_content_b");
			getall(2,"right_content_c");
			getall_A(3,"right_content_d");
		}
		else if(type=="admin"){
			getall_(1,"right_content_b");
			getall_A(3,"right_content_d");
			
			getall_e(3,"right_content_e");
			
		}
	//搜查
		$("#search_by_id_sure").click(function(){
				$(".search_show").empty();
			
			console.log($("#search_by_id").val());
			axios({
				method: 'get',
				url:'http://47.95.3.253:8080/website/api/query/document/old_name/'+$("#search_by_id").val(),
				responseType:'json',
			}).then(function(response){
				console.log(response.data.data);
				if(response.data.data.length==0) alert("无该文件信息");
				else{
					for(var i=0;i<response.data.data.length;i++){
					
						
						
						var em_num=$("<div></div>");
						var label=$("<p></p>").text("文件名");
						var em_num_one=$("<p></p>").text(response.data.data[i].old_name);
						em_num.append(label);
						em_num.append(em_num_one);
						em_num.attr("class","em_num");
						
						var base_salary=$("<div></div>");
						var label=$("<p></p>").text("后缀类型");
						var base_salary_one=$("<p></p>").text(response.data.data[i].suffixes);
						base_salary.append(label);
						base_salary.append(base_salary_one);
						base_salary.attr("class","base_salary");
						
						var attendance=$("<div></div>");
						var label=$("<p></p>").text("上传者");
						var attendance_one=$("<p></p>").text(response.data.data[i].upload);
						attendance.append(label);
						attendance.append(attendance_one);
						attendance.attr("class","attendance");
						
						
						var bonus=$("<div></div>");
						var label=$("<p></p>").text("上传时间");
						var bonus_one=$("<p></p>").text(response.data.data[i].date);
						bonus.append(label);
						bonus.append(bonus_one);
						bonus.attr("class","bonus");
						
						var attend_bonus=$("<div></div>");
						var label=$("<p></p>").text("文件大小");
						var attend_bonus_one=$("<p></p>").text(response.data.data[i].size);
						attend_bonus.append(label);
						attend_bonus.append(attend_bonus_one);
						attend_bonus.attr("class","attend_bonus");
						
						
						
						var calculate_salary=$("<div></div>");
						var label=$("<p></p>").text("浏览量");
						var calculate_salary_one=$("<p></p>").text(response.data.data[i].views);
						calculate_salary.append(label);
						calculate_salary.append(calculate_salary_one);
						calculate_salary.attr("class","calculate_salary");
						
						var deduction=$("<div></div>");
						var label=$("<p></p>").text("下载量");
						var deduction_one=$("<p></p>").text(response.data.data[i].downloads);
						deduction.append(label);
						deduction.append(deduction_one);
						deduction.attr("class","deduction");
						
					
						
						
						var div=$("<div></div>");
						div.attr("id",response.data.data[i].id);
						div.attr("class",response.data.data[i].month);
						
						
						
						div.append(em_num);
						div.append(base_salary);
						div.append(attendance);
						div.append(bonus);
						div.append(attend_bonus);
						div.append(calculate_salary);
						div.append(deduction);
						
						
						$(".search_show").append(div);
					}
				}
			});
		})

		$("#edit").click(function(){
			if($(this).html()=="编辑"){
				$(this).html("确认");
				
				
			
				
				$new_node=$("<input type='text' size='40' />");
				$new_node.val($("#id_num").html());
				$("#id_num").html("");
				$("#id_num").append($new_node);
				
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#born").html());
				$("#born").html("");
				$("#born").append($new_node);
				

				
			}
			else if($(this).html()=="确认"){
				$(this).html("编辑");

				

				
				
				var text=$("#id_num>input").val();
				$("#id_num").empty();
				$("#id_num").html(text);
				
				var text=$("#born>input").val();
				$("#born").empty();
				$("#born").html(text);
				
		

				
			
				var storage=window.localStorage;
				var num=storage.getItem("user_name");
				
				var m=$("#name").html();
				var sex;
				if($("#sex").html()=="男") sex="0";
				else sex="1";

				var m=$("#name").html();
				var i=$("#id_num").html();
				var b=$("#born").html();
				var n=$("#nation").html();
				var content;
				if(n=="可以上传下载")
					content=1;
				else if(n=="可以上传")
					content=2;
				else if(n=="可以下载")
					content=3;
				else if(n=="不可以上传下载")
					content=4;
	
				axios({
					method: 'post',
					url:'http://47.95.3.253:8080/website/api/update/user',
					responseType:'json',
					data:{
						 username: m,
						 sex: sex,
						 info: i,
						 birth: b,
						 limit: content,
					}
					}).then(function(response){
						console.log(response.data.data);
					});
				}
		});
	//预览
	
	$("#search_by_name_sure").click(function(){
		$("#name_show").empty();
		axios({
			method: 'get',
			url:'http://47.95.3.253:8080/website/api/query/user/username/'+$("#search_by_name").val(),
			responseType:'json',
		}).then(function(response){
			console.log(response.data.data.username);
			if(response.data.msg!="OK") alert("无该文件信息");
			else{
				
					
					var em_num=$("<div></div>");
					var label=$("<p></p>").text("名字");
					var em_num_one=$("<p></p>").text(response.data.data.username);
					em_num.append(label);
					em_num.append(em_num_one);
					em_num.attr("class","em_num");
					
					console.log("h");
					
					var base_salary=$("<div></div>");
					var label=$("<p></p>").text("性别");
					console.log(response.data.data);
					if(response.data.data.sex==0)
						var base_salary_one=$("<p></p>").text("男");
					else
						var base_salary_one=$("<p></p>").text("女");
					base_salary.append(label);
					base_salary.append(base_salary_one);
					base_salary.attr("class","base_salary");
					
					console.log("b");
					var attendance=$("<div></div>");
					var label=$("<p></p>").text("简介");
					var attendance_one=$("<p></p>").text(response.data.data.info);
					attendance.append(label);
					attendance.append(attendance_one);
					attendance.attr("class","attendance");
					
					
					var bonus=$("<div></div>");
					var label=$("<p></p>").text("出生日期");
					var bonus_one=$("<p></p>").text(response.data.data.birth);
					bonus.append(label);
					bonus.append(bonus_one);
					bonus.attr("class","bonus");
					
					var attend_bonus=$("<div></div>");
					var label=$("<p></p>").text("权限大小");
					var attend_bonus_one=$("<p></p>").text(response.data.data.limit);
					attend_bonus.append(label);
					attend_bonus.append(attend_bonus_one);
					attend_bonus.attr("class","attend_bonus");
					
					var div=$("<div></div>");
					
					
					div.append(em_num);
					div.append(base_salary);
					div.append(attendance);
					div.append(bonus);
					div.append(attend_bonus);
			
					$("#name_show").append(div);
				
			}
		});

})

	//
		if(type=="admin"){
			$(".right_content_c").css("display","none");
		}
		else{
			$(".right_content_e").css("display","none");
			$(".right_content_h").css("display","none");		}
	if(type=="admin"){
		$("#edit").css("display","none");
		$("#detail").empty();
		axios({
			  method: 'get',
			  url:'http://47.95.3.253:8080/website/api/query/user/username/'+user,
			  responseType:'json',
		
		}).then(function(response) {
			$("#detail").append("<p></p>").html("");
		})
	}
})

function getall(i,who){
	var storage=window.localStorage;
	var name=storage.getItem("user_name");
	var where;
	if(i==1)
	where="http://47.95.3.253:8080/website/api/query/document/all";
	if(i==2)
	where="http://47.95.3.253:8080/website/api/query/document/upload/"+name;


	axios({
		method: 'get',
		url:where,
		responseType:'json',
	}).then(function(response){
		for(var i=0;i<=response.data.data.length;i++){
			console.log("a");
			
			var tr=$("<tr></tr>");
			var j=i+1;
			var temp=$("<td></td>").html(j);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].old_name);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].suffixes);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].upload);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].date);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].size);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].downloads);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].views);
			tr.append(temp);
			
			var temp=$("<td></td>");
			var tenp=$("<a>预览</a>");
			tenp.attr("name",response.data.data[i].new_name);
			tenp.attr("id",response.data.data[i].suffixes);
			tenp.attr("class","preview");
			tenp.click(function(){
				var storage=window.localStorage;//创建访问localStorage的对象
				var user=storage.getItem("user_name");
				var which=$(this).attr("id");
				console.log(which);
				axios({
					method: 'post',
					url:"http://47.95.3.253:8080/website/api/document/preview?new_name="+$(this).attr("name"),
					responseType:'json',
				
				}).then(function(response){
					if(which=="jpg"||which=="jpeg"||which=="png") window.open(response.data.data);
					else alert(response.data.data);
					console.log(response.data);
				})
			})

			temp.append(tenp);
			tr.append(temp);

			var temp=$("<td></td>");
			var tenp=$("<a>下载</a>");
			tenp.attr("name",response.data.data[i].new_name);
			tenp.attr("class","download");
			tenp.click(function(){
				var storage=window.localStorage;//创建访问localStorage的对象
				var user=storage.getItem("user_name");
				console.log($(this).attr("name"));
				axios({
					method: 'post',
					url:"http://47.95.3.253:8080/website/api/document/download?new_name="+$(this).attr("name")+"&upload="+user,
					responseType:'json',

				}).then(function(response){
					window.open(response.data.data);
					console.log(response.data.data);
				})
			})

			temp.append(tenp);
			tr.append(temp);
		
			$("#"+who+" .show_table").append(tr);
		}
	}).catch(function (error){
	});
}


function getall_A(i,who){
	var storage=window.localStorage;
	var name=storage.getItem("user_name");
	var where;
	if(i==3)
	where="http://47.95.3.253:8080/website/api/query/record/all";

	axios({
		method: 'get',
		url:where,
		responseType:'json',
	}).then(function(response){
		for(var i=0;i<response.data.data.length;i++){
			console.log(response.data.data.length);
			
			var tr=$("<tr></tr>");
			var j=i+1;
			var temp=$("<td></td>").html(j);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].file_name);
			tr.append(temp);
			
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].name);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].date);
			tr.append(temp);
			
			var temp=$("<td></td>");
			if(response.data.data[i].isupload==1)
			temp.html('上传');
			else if(response.data.data[i].isupload==0)
			temp.html('下载');
			tr.append(temp);
		
			$("#"+who+" .show_table").append(tr);
		}
	}).catch(function (error){
	});
}


function getall_(i,who){
	var storage=window.localStorage;
	var name=storage.getItem("user_name");
	var where;
	if(i==1)
	where="http://47.95.3.253:8080/website/api/query/document/all";
	if(i==2)
	where="http://47.95.3.253:8080/website/api/query/document/upload/"+name;
	if(i==3)
	where="http://47.95.3.253:8080/website/api/query/document/upload/"+name;

	axios({
		method: 'get',
		url:where,
		responseType:'json',
	}).then(function(response){
		for(var i=0;i<=response.data.data.length;i++){
			console.log("a");
			
			var tr=$("<tr></tr>");
			var j=i+1;
			var temp=$("<td></td>").html(j);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].old_name);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].suffixes);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].upload);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].date);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].size);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].downloads);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].views);
			tr.append(temp);
			
			var temp=$("<td></td>");
			var tenp=$("<a>预览</a>");
			tenp.attr("name",response.data.data[i].new_name);
			tenp.attr("class","preview");
			tenp.attr("id",response.data.data[i].suffixes);
			tenp.click(function(){
				var storage=window.localStorage;//创建访问localStorage的对象
				var user=storage.getItem("user_name");
				var which=$(this).attr("id");
				console.log(which);
				axios({
					method: 'post',
					url:"http://47.95.3.253:8080/website/api/document/preview?new_name="+$(this).attr("name"),
					responseType:'json',
				
				}).then(function(response){
					if(which=="jpg"||which=="jpeg"||which=="png") window.open(response.data.data);
					else alert(response.data.data);
					console.log(response.data);
				})
			})

			temp.append(tenp);
			tr.append(temp);

			var temp=$("<td></td>");
			var tenp=$("<a>下载</a>");
			tenp.attr("name",response.data.data[i].new_name);
			tenp.attr("class","download");
			tenp.click(function(){
				var storage=window.localStorage;//创建访问localStorage的对象
				var user=storage.getItem("user_name");
				console.log($(this).attr("name"));
				axios({
					method: 'post',
					url:"http://47.95.3.253:8080/website/api/document/download?new_name="+$(this).attr("name")+"&upload="+user,
					responseType:'json',

				}).then(function(response){
					window.open(response.data.data);
					console.log(response.data.data);
				})
			})

			temp.append(tenp);
			tr.append(temp);
			
			if(true){
				var temp=$("<td></td>");
				var tenp=$("<a>删除</a>");
				tenp.attr("name",response.data.data[i].new_name);
				tenp.attr("class","delete");
				tenp.click(function(){
					var n=$(this).attr("name");
					alert(n);
					axios({
						method: 'post',
						url:"http://47.95.3.253:8080/website/api/delete/document?new_name="+n,
						responseType:'json',
						
					}).then(function(response){
					})
					
					
				})
				temp.append(tenp);
				tr.append(temp);
			}
			
			
			$("#"+who+" .show_table").append(tr);
		}
	}).catch(function (error){
	});
}


function getall_e(i,who){
	var storage=window.localStorage;
	var name=storage.getItem("user_name");
	var where;
	where="http://47.95.3.253:8080/website/api/query/user/all";

	axios({
		method: 'get',
		url:where,
		responseType:'json',
	}).then(function(response){
		for(var i=0;i<=response.data.data.length;i++){
			console.log("a");
			
			var tr=$("<tr></tr>");
			var j=i+1;
			var temp=$("<td></td>").html(j);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].username);
			tr.append(temp);
			
			var temp=$("<td></td>");
			if(response.data.data[i].sex==0)
			temp.html('男');
			else
			temp.html('女');
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].info);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].birth);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].limit);
			tr.append(temp);
		
			$("#"+who+" .show_table").append(tr);
		}
	}).catch(function (error){
	});
}