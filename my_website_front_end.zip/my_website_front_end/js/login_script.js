


$(function(){
	


	var h=window.screen.height;
	$("body").css("height",h+"px");
	
	
	var who="user";
	$("#radio_1").click(function(){
		
		var storage=window.localStorage;//创建访问localStorage的对象
		who="user";
		storage.setItem("user_type",who);
		console.log(who);
	
	})
	$("#radio_2").click(function(){
		var storage=window.localStorage;//创建访问localStorage的对象
		who="admin";
		storage.setItem("user_type",who);
		console.log(who);
	
	})
	
	$("#radio_1").click();
	console.log(who);
	
	
	$("#login").click(function(){
		var make=true;
		if(form1.username.value==''&&form1.password.value==''){
			alert('用户名和密码不能为空！');
			make=false;
		}
		else if(form1.username.value==''){
			alert('用户名不能为空！');
			make=false;
		}
		else if(form1.password.value==''){
			alert('密码不能为空！');
			make=false;
		}

		
		// 验证账号密码
		if(make==true){
			axios({
				method: 'post',
				url:'http://47.95.3.253:8080/website/api/'+who+'/login?username='+$("#username").val()+"&password="+$("#password").val(),
				responseType:'json',

			}).then(function(response) {
				console.log(response);
				if(response.data.data.login_state=="true"){
						var storage=window.localStorage;//创建访问localStorage的对象
						storage.setItem("user_name",response.data.data.username);

						window.open("Show.html");
						window.close();
				}
				else if(response.data.data.login_state=="false"){
					alert("账号和密码不匹配");
				}
				
			}).catch(function (error) {
				alert("链接错误");
			});
		}
	})
})