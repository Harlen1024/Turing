package com.springboot.website.serviceImpl;

import com.springboot.website.entity.FileProperties;
import com.springboot.website.service.FileUpAndDownService;
import com.springboot.website.tool.filetool.IStatusMessage;
import com.springboot.website.tool.filetool.ServiceException;
import net.coobird.thumbnailator.Thumbnails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class FileUpAndDownServiceImpl implements FileUpAndDownService {

    //本地图片url
    /*private static final String ip = "C:"+"/"+"Users"+"/"+"Z&C"+"/"+"Desktop"+"/"+"salary-manager"+"/"
            +"src"+"/"+"main"+"/"+"resources"+"/"+"static"+"/"+"excel"+"/";*/
    private static final String static_url = "C:"+"/"+"Program Files"+"/"+"Apache Software Foundation"+"/"+"Tomcat 9.0"+"/"
            +"webapps"+"/"+"website"+"/"+"WEB-INF"+"/"+"classes"+"/"+"static"+"/"+"document"+"/";

    private static final String dynamic_url = "http://47.95.3.253:8080/website/document";

    @Autowired
    private FileProperties config; //用来获取file-message.properties配置文件中的信息

    @Override
    public Map<String, Object> uploadPicture(MultipartFile file) throws ServiceException {
        try {
            Map<String, Object> resMap = new HashMap<String, Object>();
            String[] IMAGE_TYPE = config.getFileType().split(",");
            String path = null;
            boolean flag = false;
            for (String type : IMAGE_TYPE) {
                if (StringUtils.endsWithIgnoreCase(file.getOriginalFilename(), type)) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                resMap.put("result", IStatusMessage.SystemStatus.SUCCESS.getMessage());
                String uuid = UUID.randomUUID().toString().replaceAll("-", "");
                // 获得文件类型
                String fileType = file.getContentType();
                System.out.println(fileType);
                // 获得文件后缀名称
                String fileName = fileType.substring(fileType.indexOf("/") + 1);
                //MIME类型转换
                if(fileName.equals("vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
                    fileName = "xlsx";
                }
                else if(fileName.equals("vnd.ms-excel")){
                    fileName = "xls";
                }
                else if(fileName.equals("vnd.openxmlformats-officedocument.wordprocessingml.document")){
                    fileName = "docx";
                }
                else if(fileName.equals("msword")){
                    fileName = "doc";
                }
                else if(fileName.equals("vnd.openxmlformats-officedocument.presentationml.presentation")){
                    fileName = "pptx";
                }
                else if(fileName.equals("vnd.ms-powerpoint")){
                    fileName = "pptx";
                }
                // 原名称
                String oldFileName = file.getOriginalFilename();
                System.out.println(file.getOriginalFilename());
                // 新名称
                String newFileName = uuid + "." + fileName;
                // 年月日文件夹
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                String basedir = sdf.format(new Date());
                // 进行压缩(大于4M)
                if (file.getSize() > config.getFileSize()) {
                    // 重新生成
                    String newUUID = UUID.randomUUID().toString().replaceAll("-", "");
                    newFileName = newUUID + "." + fileName;
                    path = config.getUpPath() + "/" + basedir + "/" + newUUID + "." + fileName;
                    // 如果目录不存在则创建目录
                    File oldFile = new File(path);
                    if (!oldFile.exists()) {
                        oldFile.mkdirs();
                    }
                    file.transferTo(oldFile);
                    // 压缩图片
                    Thumbnails.of(oldFile).scale(config.getScaleRatio()).toFile(path);
                    // 显示路径
                    resMap.put("static_path", static_url + "/" + basedir + "/" + newUUID + "." + fileName);
                    resMap.put("dynamic_path", dynamic_url + "/" + basedir + "/" + newUUID + "." + fileName);
                } else {
                    path = config.getUpPath() + "/" + basedir + "/" + uuid + "." + fileName;
                    // 如果目录不存在则创建目录
                    File uploadFile = new File(path);
                    if (!uploadFile.exists()) {
                        uploadFile.mkdirs();
                    }
                    file.transferTo(uploadFile);
                    // 显示路径
                    resMap.put("static_path", static_url + "/" + basedir + "/" + uuid + "." + fileName);
                    resMap.put("dynamic_path", dynamic_url + "/" + basedir + "/" + uuid + "." + fileName);
                }
                resMap.put("oldFileName", oldFileName);
                resMap.put("newFileName", newFileName);
                resMap.put("fileSize", file.getSize() + "kb");
                resMap.put("suffixes", fileName);
            } else {
                resMap.put("result", "文件格式不正确,支持xls,xlsx,doc,docx,ppt,pptx,png,pdf,jpg,mp3,wav,txt,zip");
            }
            return resMap;
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException(e.getMessage());
        }
    }
}