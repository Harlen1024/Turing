package com.springboot.website.serviceImpl;

import com.springboot.website.entity.User;
import com.springboot.website.mapper.UserMapper;
import com.springboot.website.service.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> getAllUser() {

        List<User> list = this.userMapper.getAllUser();

        return list;

    }

    @Override
    public User queryUserByName(String username){

        User user = this.userMapper.queryUserByName(username);

        return user;
    }

    @Override
    public int insertUser(User user){

        int temp = this.userMapper.insertUser(user);

        return temp;

    }

    @Override
    public int updateUser(User user){

        int temp = this.userMapper.updateUser(user);

        return temp;
    }

    @Override
    public int updateUserLimit(@Param("limit") String limit, @Param("username") String username){

        int temp = this.userMapper.updateUserLimit(limit, username);

        return temp;
    }


}
