package com.springboot.website.service;

import com.springboot.website.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {

    List<User> getAllUser();

    User queryUserByName(String username);

    int insertUser(User user);

    int updateUser(User user);

    int updateUserLimit(@Param("limit") int limit, @Param("username") String username);

}
