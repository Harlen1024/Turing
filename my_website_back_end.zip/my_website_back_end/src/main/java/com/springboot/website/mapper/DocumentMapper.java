package com.springboot.website.mapper;

import com.springboot.website.entity.Document;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface DocumentMapper {

    //查询全部
    @Select("select * from document")
    List<Document> getAllDocument();

    //按新生成的uuid文件名查询
    @Select("SELECT * FROM document WHERE new_name = #{new_name} ")
    Document queryDocumentByNew_name(@Param("new_name") String new_name);

    //按上传者查询
    @Select("SELECT * FROM document WHERE upload = #{upload} ")
    List<Document> queryDocumentByUpload(@Param("upload") String upload);

    //按旧文件名（模糊）
    @Select("SELECT * FROM document WHERE old_name like '%${value}%'")
    List<Document> queryDocumentByOld_name(String old_name);

    //添加的文档记录
    @Insert("INSERT INTO document (old_name,  new_name, suffixes, static_url, dynamic_url, upload, date, size, downloads, views) "
            + "VALUES (#{old_name}, #{new_name}, #{suffixes}, #{static_url}, #{dynamic_url}, #{upload}, #{date}, #{size}, #{downloads}, #{views})")
    int insertDocument(Document document);

    //更新插入下载次数
    @Update("UPDATE document SET `downloads`=#{downloads} WHERE new_name =#{new_name}")
    int updateDownloads(@Param("downloads") int downloads, @Param("new_name") String new_name);

    //更新插入浏览次数
    @Update("UPDATE document SET `views`=#{views} WHERE new_name =#{new_name}")
    int updateViews(@Param("views") int views, @Param("new_name") String new_name);

    @Delete("delete from document where new_name = #{new_name}")
    int deleteDocument(String new_name);

}
