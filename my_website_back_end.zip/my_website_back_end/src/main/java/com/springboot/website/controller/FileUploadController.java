package com.springboot.website.controller;

import com.springboot.website.entity.Document;
import com.springboot.website.entity.Record;
import com.springboot.website.service.DocumentService;
import com.springboot.website.service.FileUpAndDownService;
import com.springboot.website.service.RecordService;
import com.springboot.website.tool.datetool.DateResult;
import com.springboot.website.tool.filetool.IStatusMessage;
import com.springboot.website.tool.filetool.ResponseResult;
import com.springboot.website.tool.filetool.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/upload")
public class FileUploadController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadController.class);

    @Autowired
    private FileUpAndDownService fileUpAndDownService;

    @Autowired
    private DocumentService documentService;

    @Autowired
    private RecordService recordService;

    @RequestMapping(value = "/setFileUpload", method = RequestMethod.POST)
    @ResponseBody
    public ResponseResult setFileUpload(@RequestParam(value = "file") MultipartFile file, @RequestParam(value = "upload") String upload) {
        ResponseResult result = new ResponseResult();

        Document document = new Document();

        Record record = new Record();

        //时间类获取当前上传时间
        DateResult dateResult = new DateResult();

        //记录当前上传时间
        String upload_date = dateResult.getCurrentTime();

        try {
            Map<String, Object> resultMap = upload(file);
            if (!IStatusMessage.SystemStatus.SUCCESS.getMessage().equals(resultMap.get("result"))) {
                result.setCode(IStatusMessage.SystemStatus.PARAM.getCode());
                result.setMessage((String) resultMap.get("msg"));
                return result;
            }

            //文档上传成功即更新到数据库对应的记录文件表
            document.setOld_name(resultMap.get("oldFileName").toString());
            document.setNew_name(resultMap.get("newFileName").toString());
            document.setSuffixes(resultMap.get("suffixes").toString());
            document.setStatic_url(resultMap.get("static_path").toString());
            document.setDynamic_url(resultMap.get("dynamic_path").toString());
            document.setUpload(upload);
            document.setDate(upload_date);
            document.setSize(resultMap.get("fileSize").toString());

            //上传时浏览量与下载量初始化为0
            document.setDownloads(0);
            document.setViews(0);

            documentService.insertDocument(document);

            //同时更新上传or下载流动记录表
            record.setName(upload);
            record.setFile_name(resultMap.get("oldFileName").toString());
            record.setDate(upload_date);
            //上传为1下载为0
            record.setIsupload(1);

            recordService.insertRecord(record);

            result.setData(resultMap);

        } catch (ServiceException e) {
            e.printStackTrace();
            LOGGER.error(">>>>>>图片上传异常，e={}", e.getMessage());
            result.setCode(IStatusMessage.SystemStatus.ERROR.getCode());
            result.setMessage(IStatusMessage.SystemStatus.ERROR.getMessage());
        }
        return result;
    }

    private Map<String, Object> upload(MultipartFile file) throws ServiceException {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        try {
            if (!file.isEmpty()) {
                Map<String, Object> picMap = fileUpAndDownService.uploadPicture(file);
                if (IStatusMessage.SystemStatus.SUCCESS.getMessage().equals(picMap.get("result"))) {
                    return picMap;
                } else {
                    returnMap.put("result", IStatusMessage.SystemStatus.ERROR.getMessage());
                    returnMap.put("msg", picMap.get("result"));
                }
            } else {
                LOGGER.info(">>>>>>上传图片为空文件");
                returnMap.put("result", IStatusMessage.SystemStatus.FILE_UPLOAD_NULL.getMessage());
                returnMap.put("msg", IStatusMessage.SystemStatus.FILE_UPLOAD_NULL.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException(IStatusMessage.SystemStatus.ERROR.getMessage());
        }
        return returnMap;
    }
}
