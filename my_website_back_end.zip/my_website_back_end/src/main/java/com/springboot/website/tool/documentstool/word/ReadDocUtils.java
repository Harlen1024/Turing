package com.springboot.website.tool.documentstool.word;

        import java.io.File;
        import java.io.FileInputStream;
        import java.io.IOException;

        import org.apache.poi.hwpf.extractor.WordExtractor;

public class ReadDocUtils {

    /**
     * 读取doc文件内容
     *
     * 想要读取的文件对象
     * @return 返回文件内容
     * @throws IOException
     */

    public String ReadDocUtils(FileInputStream fs) throws IOException {
        StringBuilder result = new StringBuilder();
        WordExtractor re = new WordExtractor(fs);
        result.append(re.getText());
        re.close();
        return result.toString();
    }

    public String ReadDocUtils(File file) throws IOException {
        return ReadDocUtils(new FileInputStream(file));
    }

    public static void main(String[] args) {
        /*File file = new File("D:1.doc");
        try {
            System.out.println(ReadDocUtils(file));
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}
