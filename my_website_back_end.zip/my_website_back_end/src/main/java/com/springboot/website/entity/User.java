package com.springboot.website.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

//网站一般用户对应的实体类
@Entity
public class User {

    //id
    @Id
    private int id;

    //用户名
    private String username;

    //密码
    private String password;

    //性别
    private int sex;

    //个人简介
    private String info;

    //出生日期
    private String birth;

    //权限限制 1：可下载可上传 2：只可下载 3：只可上传 4：均不可
    private int limit;

    //登录状态 true/false
    private String login_state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getLogin_state() {
        return login_state;
    }

    public void setLogin_state(String login_state) {
        this.login_state = login_state;
    }
}
