package com.springboot.website.mapper;

import com.springboot.website.entity.Record;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RecordMapper {

    //查询全部
    @Select("select * from record")
    List<Record> getAllRecord();

    //添加上传or下载记录
    @Insert("INSERT INTO record (name,  file_name, date, isupload) "
            + "VALUES (#{name}, #{file_name}, #{date}, #{isupload})")
    int insertRecord(Record record);

}
