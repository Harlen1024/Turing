package com.springboot.website.serviceImpl;

import com.springboot.website.entity.Record;
import com.springboot.website.mapper.RecordMapper;
import com.springboot.website.service.RecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecordServiceImpl implements RecordService {

    @Autowired
    private RecordMapper recordMapper;

    @Override
    public List<Record> getAllRecord() {

        List<Record> list = this.recordMapper.getAllRecord();

        return list;

    }

    @Override
    public int insertRecord(Record record){

        int temp = this.recordMapper.insertRecord(record);

        return temp;

    }

}
