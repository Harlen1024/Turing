package com.springboot.website.serviceImpl;

import com.springboot.website.entity.Document;
import com.springboot.website.mapper.DocumentMapper;
import com.springboot.website.service.DocumentService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    private DocumentMapper documentMapper;

    @Override
    public List<Document> getAllDocument() {

        List<Document> list = this.documentMapper.getAllDocument();

        return list;

    }

    @Override
    public Document queryDocumentByNew_name(String new_name){

        Document document = this.documentMapper.queryDocumentByNew_name(new_name);

        return document;
    }

    @Override
    public List<Document> queryDocumentByUpload(@Param("upload") String upload){

        List<Document> list = this.documentMapper.queryDocumentByUpload(upload);

        return list;
    }

    @Override
    public List<Document> queryDocumentByOld_name(String old_name){

        List<Document> list = this.documentMapper.queryDocumentByOld_name(old_name);

        return list;
    }

    @Override
    public int insertDocument(Document document){

        int temp = this.documentMapper.insertDocument(document);

        return temp;

    }

    @Override
    public int updateDownloads(@Param("downloads") int downloads, @Param("new_name") String new_name){

        int temp = this.documentMapper.updateDownloads(downloads,new_name);

        return temp;
    }

    @Override
    public int updateViews(@Param("views") int views, @Param("new_name") String new_name){

        int temp = this.documentMapper.updateViews(views,new_name);

        return temp;
    }

    @Override
    public int deleteDocument(String new_name){

        int temp = this.documentMapper.deleteDocument(new_name);

        return temp;
    }
}
