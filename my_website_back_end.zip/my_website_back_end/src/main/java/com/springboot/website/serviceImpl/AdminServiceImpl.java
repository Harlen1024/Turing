package com.springboot.website.serviceImpl;

import com.springboot.website.entity.Admin;
import com.springboot.website.mapper.AdminMapper;
import com.springboot.website.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Admin queryAdminByName(String username){

        Admin admin = this.adminMapper.queryAdminByName(username);

        return admin;
    }

    @Override
    public int insertAdmin(Admin admin){

        int temp = this.adminMapper.insertAdmin(admin);

        return temp;

    }

}
