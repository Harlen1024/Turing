package com.springboot.website.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

//记录上传或下载流动记录的实体类
@Entity
public class Record {

    //id
    @Id
    private int id;

    //操作的用户名
    private String name;

    //文件名
    private String file_name;

    //操作的时间
    private String date;

    //上传or下载（int） 1：上传 0：下载
    private int isupload;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getIsupload() {
        return isupload;
    }

    public void setIsupload(int isupload) {
        this.isupload = isupload;
    }
}
