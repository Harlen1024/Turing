package com.springboot.website.service;

import com.springboot.website.entity.Record;

import java.util.List;

public interface RecordService {

    List<Record> getAllRecord();

    int insertRecord(Record record);

}
