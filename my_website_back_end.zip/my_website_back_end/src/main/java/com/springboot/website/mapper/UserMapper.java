package com.springboot.website.mapper;

import com.springboot.website.entity.Document;
import com.springboot.website.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    //查询全部
    @Select("select * from user")
    List<User> getAllUser();

    //按用户名查找
    @Select("SELECT * FROM user WHERE username like '%${value}%'")
    User queryUserByName(String username);

    //添加新用户
    @Insert("INSERT INTO user (username,  password) "
            + "VALUES (#{username}, #{password})")
    int insertUser(User user);

    //更新用户信息
    @Update("UPDATE user SET " +
            "sex=#{sex}, " +
            "info=#{info}, " +
            "birth=#{birth} " +
            "WHERE username=#{username}")
    int updateUser(User user);

    //更新用户权限
    @Update("UPDATE article SET `limit`=#{limit} WHERE username=#{username}")
    int updateUserLimit(@Param("limit") String limit, @Param("username") String username);

}
