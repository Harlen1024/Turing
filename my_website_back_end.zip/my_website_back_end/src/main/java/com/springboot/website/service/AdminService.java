package com.springboot.website.service;

import com.springboot.website.entity.Admin;

public interface AdminService {

    Admin queryAdminByName(String username);

    int insertAdmin(Admin admin);

}
