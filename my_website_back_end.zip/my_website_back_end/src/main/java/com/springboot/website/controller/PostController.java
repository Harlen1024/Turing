package com.springboot.website.controller;


import com.springboot.website.entity.Admin;
import com.springboot.website.entity.Document;
import com.springboot.website.entity.Record;
import com.springboot.website.entity.User;
import com.springboot.website.service.AdminService;
import com.springboot.website.service.DocumentService;
import com.springboot.website.service.RecordService;
import com.springboot.website.service.UserService;
import com.springboot.website.tool.datetool.DateResult;
import com.springboot.website.tool.documentstool.excel.ReadExcelUtils;
import com.springboot.website.tool.documentstool.word.ReadDocUtils;
import com.springboot.website.tool.jsontool.JsonResult;
import com.springboot.website.tool.md5tool.Md5Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** 所有的post请求的接口
 *  1./api/admin/login 管理员登录用api 键值为二 value = username && password 成功返回“succeed” 失败返回“defeat”
 *  2./api/user/login 普通用户登录用api 键值为二 value = username && password 成功返回“succeed” 失败返回“defeat”
 *  3./api/admin/register 管理员注册用api 键值为二 value = username && password
 *  4./api/user/register 普通用户注册用api 键值为二 value = username && password
 *  5./api/update/user 更新用户基本信息的接口 post为一个json整体
 *  6./api/document/download 获得下载对应文档的地址 键值为一 value = new_name
 *  7./api/document/preview 实现word excel 各图片的预览 键值为一 value = new_name
 *  8./api/update/user/limit 更新用户基本信息的权限 键值为二 value = limit && username
 *  9./api/delete/document 删除对应文档记录 键值为一 value = new_name
 */

@RestController
@CrossOrigin
@RequestMapping("/api")
public class PostController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserService userService;

    @Autowired
    private DocumentService documentService;

    @Autowired
    private RecordService recordService;

    //根据用户名登录
    @RequestMapping(value = "/admin/login", method = RequestMethod.POST)
    public JsonResult adminLogin(@RequestParam(value = "username") String username,
                                 @RequestParam(value = "password") String password) {

        Admin admin = this.adminService.queryAdminByName(username);

        //密码不正确时的实例
        Admin wrong_admin = new Admin();

        //MD5加密
        Md5Result getMD5 = new Md5Result();

        if(admin != null) {
            if (admin.getPassword().equals(getMD5.getMD5Code(password))) {

                admin.setLogin_state("true");
                return JsonResult.ok(admin);

            }
        }

        wrong_admin.setUsername(username);
        wrong_admin.setPassword(password);
        wrong_admin.setLogin_state("false");

        return JsonResult.ok(wrong_admin);

    }

    //根据用户名登录
    @RequestMapping(value = "/user/login", method = RequestMethod.POST)
    public JsonResult userLogin(@RequestParam(value = "username") String username,
                                 @RequestParam(value = "password") String password) {

        User user = this.userService.queryUserByName(username);

        //密码不正确时的实例
        User wrong_user = new User();

        //MD5加密
        Md5Result getMD5 = new Md5Result();

        if(user != null) {
            if (user.getPassword().equals(getMD5.getMD5Code(password))) {

                user.setLogin_state("true");
                return JsonResult.ok(user);

            }
        }

        wrong_user.setUsername(username);
        wrong_user.setPassword(password);
        wrong_user.setLogin_state("false");

        return JsonResult.ok(wrong_user);

    }

    //注册管理员
    @RequestMapping(value = "/admin/register", method = RequestMethod.POST)
    public JsonResult adminRegister(@RequestParam(value = "username") String username,
                                @RequestParam(value = "password") String password) {

        Admin admin = new Admin();

        admin.setUsername(username);

        //MD5加密
        Md5Result getMD5 = new Md5Result();

        admin.setPassword(getMD5.getMD5Code(password));

        admin.setLogin_state("true");

        adminService.insertAdmin(admin);

        return JsonResult.ok(admin);

    }

    //注册用户
    @RequestMapping(value = "/user/register", method = RequestMethod.POST)
    public JsonResult userRegister(@RequestParam(value = "username") String username,
                                    @RequestParam(value = "password") String password) {
        User user = new User();

        user.setUsername(username);

        //MD5加密
        Md5Result getMD5 = new Md5Result();

        user.setPassword(getMD5.getMD5Code(password));

        //注册时默认权限等级为1 ：可上传及下载
        user.setLimit(1);

        user.setLogin_state("true");

        userService.insertUser(user);

        return JsonResult.ok(user);

    }

    @RequestMapping(value = "update/user", method = RequestMethod.POST)
    public Map<String, Object> updateUser(@RequestBody User user) {

        //默认为1
        user.setLimit(1);

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("user", user);
//        employeeService.updateEmploy(employee, employee.getEm_num());
//        System.out.println(employee.getEm_num());
        userService.updateUser(user);
        return param;
    }


    //获取下载的url
    @RequestMapping(value = "document/download", method = RequestMethod.POST)
    public JsonResult getDownload(@RequestParam(value = "new_name") String new_name,
                                   @RequestParam(value = "upload") String upload) {

        //时间类获取当前上传时间
        DateResult dateResult = new DateResult();

        //记录当前上传时间
        String upload_date = dateResult.getCurrentTime();

        Document document = documentService.queryDocumentByNew_name(new_name);

        //下载量+1
        int temp = document.getDownloads();
        documentService.updateDownloads(temp+1, new_name);

        Record record = new Record();

        //同时更新上传or下载流动记录表
        record.setName(upload);
        record.setFile_name(document.getOld_name());
        record.setDate(upload_date);
        //上传为1下载为0
        record.setIsupload(0);

        recordService.insertRecord(record);

        return JsonResult.ok(document.getDynamic_url());

    }

    //在线预览处理
    @RequestMapping(value = "document/preview", method = RequestMethod.POST)
    public JsonResult getPreview(@RequestParam(value = "new_name") String new_name) {

        Document document = documentService.queryDocumentByNew_name(new_name);

        //浏览量+1
        int view_temp = document.getViews();
        documentService.updateViews(view_temp+1, new_name);

        String temp = "not support now(暂不支持该文档格式预览)";

        //word文档的预览处理
        if(document.getSuffixes().equals("doc") || document.getSuffixes().equals("docx")){

            ReadDocUtils readDocUtils = new ReadDocUtils();
            File file = new File(document.getStatic_url());
            try {

                temp = readDocUtils.ReadDocUtils(file);

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        //excel文档的预览处理
        else if(document.getSuffixes().equals("xls") || document.getSuffixes().equals("xlsx")){

            try {
                String filepath = document.getStatic_url();
                ReadExcelUtils excelReader = new ReadExcelUtils(filepath);
                // 对读取Excel表格标题测试
//			String[] title = excelReader.readExcelTitle();
//			System.out.println("获得Excel表格的标题:");
//			for (String s : title) {
//				System.out.print(s + " ");
//			}

                // 对读取Excel表格内容转为字符串
                Map<Integer, Map<Integer,Object>> map = excelReader.readExcelContent();
                temp = map.toString();

            } catch (FileNotFoundException e) {
                System.out.println("未找到指定路径的文件!");
                e.printStackTrace();
            }catch (Exception e) {
                e.printStackTrace();
            }

        }

        //图片文件的预览处理
        else if(document.getSuffixes().equals("jpg") || document.getSuffixes().equals("jpeg") || document.getSuffixes().equals("png")){

            temp = document.getDynamic_url();

        }

        return JsonResult.ok(temp);

    }

    //根据用户名更新权限
    @RequestMapping(value = "delete/document", method = RequestMethod.POST)
    public JsonResult deleteDocument(@RequestParam(value = "new_name") String new_name) {

        documentService.deleteDocument(new_name);

        return JsonResult.ok(new_name);

    }

}
