package com.springboot.website.service;

import com.springboot.website.entity.Document;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DocumentService {

    List<Document> getAllDocument();

    Document queryDocumentByNew_name(@Param("new_name") String new_name);

    List<Document> queryDocumentByUpload(@Param("upload") String upload);

    List<Document> queryDocumentByOld_name(String old_name);

    int insertDocument(Document document);

    int updateDownloads(@Param("downloads") int downloads, @Param("new_name") String new_name);

    int updateViews(@Param("views") int views, @Param("new_name") String new_name);

    int deleteDocument(String new_name);
}
