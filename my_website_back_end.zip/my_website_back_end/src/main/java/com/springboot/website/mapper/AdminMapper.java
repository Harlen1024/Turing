package com.springboot.website.mapper;

import com.springboot.website.entity.Admin;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AdminMapper {

    //按用户名查找
    @Select("SELECT * FROM admin WHERE username =#{username}")
    Admin queryAdminByName(String username);

    //添加新管理员
    @Insert("INSERT INTO admin (username,  password) "
            + "VALUES (#{username}, #{password})")
    int insertAdmin(Admin admin);

}
