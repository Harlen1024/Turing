package com.springboot.website.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

//对应数据库存放文件的实体类
@Entity
public class Document {

    //id
    @Id
    private int id;

    //旧的名称（用于显示）
    private String old_name;

    //新的名称（用于存放uuid防止文件名重复覆盖）
    private String new_name;

    //文件后缀类型
    private String suffixes;

    //静态的路径
    private String static_url;

    //动态的路径
    private String dynamic_url;

    //上传者名字
    private String upload;

    //上传时间
    private String date;

    //文件大小
    private String size;

    //下载量
    private int downloads;

    //浏览量
    private int views;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOld_name() {
        return old_name;
    }

    public void setOld_name(String old_name) {
        this.old_name = old_name;
    }

    public String getNew_name() {
        return new_name;
    }

    public void setNew_name(String new_name) {
        this.new_name = new_name;
    }

    public String getSuffixes() {
        return suffixes;
    }

    public void setSuffixes(String suffixes) {
        this.suffixes = suffixes;
    }

    public String getStatic_url() {
        return static_url;
    }

    public void setStatic_url(String static_url) {
        this.static_url = static_url;
    }

    public String getDynamic_url() {
        return dynamic_url;
    }

    public void setDynamic_url(String dynamic_url) {
        this.dynamic_url = dynamic_url;
    }

    public String getUpload() {
        return upload;
    }

    public void setUpload(String upload) {
        this.upload = upload;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getDownloads() {
        return downloads;
    }

    public void setDownloads(int downloads) {
        this.downloads = downloads;
    }

    public int getViews() {
        return views;
    }

    public void setViews(int views) {
        this.views = views;
    }
}
