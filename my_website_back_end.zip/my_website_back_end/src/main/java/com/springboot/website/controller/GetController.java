package com.springboot.website.controller;

import com.springboot.website.entity.*;
import com.springboot.website.service.AdminService;
import com.springboot.website.service.DocumentService;
import com.springboot.website.service.RecordService;
import com.springboot.website.service.UserService;
import com.springboot.website.tool.jsontool.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** 所有的get请求的接口
 *  1./api/query/document/all 查询全部的文档信息
 *  2./api/query/document/upload/{upload} 根据upload上传者查询文档信息
 *  3./api/query/document/old_name/{old_name} 根据old_name查询文档信息（模糊）
 *  4./api/query/user/username/{username} 根据用户名查询用户基本信息（模糊）
 *  5./api/query/admin/username/{username} 根据用户名查询管理员基本信息
 *  6./api/query/user/all 查询全部的文档信息
 *  7./api/query/file/type 查询全部的文档的后缀统计
 *  8./api/query/file/loads 查询全部的文档的上传下载记录
 *  9./api/query/record/all
 */

@RestController
@CrossOrigin
@RequestMapping("/api")
public class GetController {

    @Autowired
    private DocumentService documentService;

    @Autowired
    private UserService userService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private RecordService recordService;

    //mysql单类型查询()
    @RequestMapping("query/document/all")
    public JsonResult queryDocumentAll() {

        List<Document> list = this.documentService.getAllDocument();

        return JsonResult.ok(list);

    }

    //mysql单类型查询()
    @RequestMapping("query/document/upload/{upload}")
    public JsonResult querySalaryByJob_id(@PathVariable String upload) {

        List<Document> list = this.documentService.queryDocumentByUpload(upload);

        return JsonResult.ok(list);

    }

    //mysql单类型查询()
    @RequestMapping("query/document/old_name/{old_name}")
    public JsonResult querySalaryByOld_name(@PathVariable String old_name) {

        List<Document> list = this.documentService.queryDocumentByOld_name(old_name);

        return JsonResult.ok(list);

    }

    //mysql单类型查询()
    @RequestMapping("query/user/username/{username}")
    public JsonResult queryUserByName(@PathVariable String username) {

        User user = this.userService.queryUserByName(username);

        return JsonResult.ok(user);

    }

    //mysql单类型查询()
    @RequestMapping("query/admin/username/{username}")
    public JsonResult queryAdminByName(@PathVariable String username) {

        Admin admin = this.adminService.queryAdminByName(username);

        return JsonResult.ok(admin);

    }

    //mysql单类型查询()
    @RequestMapping("query/user/all")
    public JsonResult queryUserAll() {

        List<User> list = this.userService.getAllUser();

        return JsonResult.ok(list);

    }

    //mysql单类型查询()
    @RequestMapping("query/file/type")
    public JsonResult queryDocumentType() {

        int excel_temp = 0;

        int word_temp = 0;

        int ppt_temp = 0;

        int img_temp = 0;

        int other_temp = 0;

        FileType fileType = new FileType();

        List<Document> list = this.documentService.getAllDocument();

        for(int i = 0 ; i<list.size(); i++){

            if(list.get(i).getSuffixes().equals("xlsx") || list.get(i).getSuffixes().equals("xls")){
                excel_temp++;
                fileType.setExcel(excel_temp);
            }
            else if(list.get(i).getSuffixes().equals("doc") || list.get(i).getSuffixes().equals("docx")){
                word_temp++;
                fileType.setWord(word_temp);
            }
            else if(list.get(i).getSuffixes().equals("ppt") || list.get(i).getSuffixes().equals("pptx")){
                ppt_temp++;
                fileType.setPowerpoint(ppt_temp);
            }
            else if(list.get(i).getSuffixes().equals("png") || list.get(i).getSuffixes().equals("jpg") || list.get(i).getSuffixes().equals("jpeg")){
                img_temp++;
                fileType.setPowerpoint(img_temp);
            }
            else {
                other_temp++;
                fileType.setOther(other_temp);
            }

        }
        return JsonResult.ok(fileType);

    }

    //mysql单类型查询()
    @RequestMapping("query/file/loads")
    public JsonResult queryDocumentLoads() {

        int all_temp = 0;

        int uploads_temp = 0;

        int downloads_temp = 0;

        UpAndDownloads upAndDownloads = new UpAndDownloads();

        List<Record> list = this.recordService.getAllRecord();

        for(int i = 0 ; i<list.size(); i++){

            if(list.get(i).getIsupload() == 1){
                all_temp++;
                uploads_temp++;
                upAndDownloads.setAll(all_temp);
                upAndDownloads.setUploads(uploads_temp);
            }
            else if(list.get(i).getIsupload() == 0) {
                downloads_temp++;
                upAndDownloads.setDownloads(downloads_temp);
            }

        }
        return JsonResult.ok(upAndDownloads);

    }

    //mysql单类型查询()
    @RequestMapping("query/record/all")
    public JsonResult queryRecordAll() {

        List<Record> list = this.recordService.getAllRecord();

        return JsonResult.ok(list);

    }

}
