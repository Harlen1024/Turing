package com.springboot.website.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

//管理员对应的实体类
@Entity
public class Admin {

    //id
    @Id
    private int id;

    //用户名
    private String username;

    //密码
    private String password;

    //登录状态 true/false
    private String login_state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLogin_state() {
        return login_state;
    }

    public void setLogin_state(String login_state) {
        this.login_state = login_state;
    }
}
