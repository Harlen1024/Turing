package com.springboot.website.entity;

//统计分析文件类型的实体类
public class FileType {

    private int excel;

    private int word;

    private int powerpoint;

    private int img;

    private int other;

    public int getExcel() {
        return excel;
    }

    public void setExcel(int excel) {
        this.excel = excel;
    }

    public int getWord() {
        return word;
    }

    public void setWord(int word) {
        this.word = word;
    }

    public int getPowerpoint() {
        return powerpoint;
    }

    public void setPowerpoint(int powerpoint) {
        this.powerpoint = powerpoint;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        this.other = other;
    }
}
